﻿using System;
using System.Threading;
using ClassLibrary3;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;

namespace WordpressTests
{
    [TestClass]
    public class LoginTest
    {
        [TestInitialize]
        public void Init()
        {
            Driver.Initialize();
        }
        [TestMethod]
        public void UserCanLogIn()
        {
            LoginPage.GoTo();
            LoginPage.LoginAs("evasileva35@gmail.com").WithPassword("dhltest678").Login();
         
            Assert.IsTrue(TestLabPage.IsAt, "Failed to login.");
        }

        [TestMethod]
        public void LogInWithRememberMe()
        {
            LoginPage.GoTo();
            LoginPage.LoginAs("evasileva35@gmail.com").WithPassword("dhltest678").LogInWithkRememberMe();

            Assert.IsTrue(TestLabPage.IsAt, "Failed to login.");
        }


        [TestMethod]
        public void LostYourPassword()
        {
            LoginPage.GoTo();
            LoginPage.ClickLostYourPass();

            Assert.IsTrue(TestLabPage.IsAt1, "Failed to login.");
        }

        [TestCleanup]
        public void CleanUp()
        {
            Driver.Close();
        }
    }
}
