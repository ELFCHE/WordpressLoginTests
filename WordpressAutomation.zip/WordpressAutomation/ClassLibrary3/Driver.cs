﻿using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using System;
using System.IO;

namespace ClassLibrary3
{
    public class Driver
    {
        public static IWebDriver Instance { get; set; }

        public static void Initialize()
        {
            var driverPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "lib"));
            Instance = new EdgeDriver(driverPath);
            Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public static void Close()
        {
            Instance.Quit();
        }
    }
}
