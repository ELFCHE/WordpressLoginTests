﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace ClassLibrary3
{
    public class LoginPage
    {
        public static void GoTo()
        {         
            string testLabUrl = "https://lab.uk.qateam.eu/wp-login.php";
            Driver.Instance.Navigate().GoToUrl(testLabUrl);
            var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
            wait.Until(d => d.SwitchTo().ActiveElement().GetAttribute("id") == "user_login");
        }

        public static LogginCommang LoginAs(string username)
        {
            return new LogginCommang(username);         
        }

        public static void ClickLostYourPass()
        {
            var lostPassLink = Driver.Instance.FindElement(By.LinkText("Lost your password?"));
            lostPassLink.Click();
        }
    }

    public class LogginCommang
    {
        private readonly string userName;
        private string password;

        public LogginCommang(string userName)
        {
            this.userName = userName;
        }

        public LogginCommang WithPassword(string password)
        {
            this.password = password;
            return this;
        }

        public void Login()
        {
            var loginInput = Driver.Instance.FindElement(By.Id("user_login"));
            loginInput.SendKeys(userName);

            var passwordInput = Driver.Instance.FindElement(By.Id("user_pass"));
            passwordInput.SendKeys(password);

            var logginButton = Driver.Instance.FindElement(By.Id("wp-submit"));
            logginButton.Click();
        }

        public void LogInWithkRememberMe()
        {
            var loginInput = Driver.Instance.FindElement(By.Id("user_login"));
            loginInput.SendKeys(userName);

            var passwordInput = Driver.Instance.FindElement(By.Id("user_pass"));
            passwordInput.SendKeys(password);

            var logginButton = Driver.Instance.FindElement(By.Id("wp-submit"));
            logginButton.Click();

            var rememberMeCheckBox = Driver.Instance.FindElement(By.Id("rememberme"));
            rememberMeCheckBox.Click();
        }

    }
}
