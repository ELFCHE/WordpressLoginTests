﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ClassLibrary3
{
    public class TestLabPage
    {
        public static bool IsAt
        {
            get
            {
                var h1S = Driver.Instance.FindElements(By.ClassName("entry-title"));
                if (h1S.Count > 0)
                    return h1S[0].Text == "My account";
                return false;
            }
        }
        public static bool IsAt1
        {
            get
            {
                var h1S = Driver.Instance.FindElements(By.ClassName("entry-title"));
                if (h1S.Count > 0)
                    return h1S[0].Text == "Lost password";
                return false;
            }
        }
    }
}
