﻿using System;

namespace WordpressAutomation
{
    public class Class1
    {
    }
}
